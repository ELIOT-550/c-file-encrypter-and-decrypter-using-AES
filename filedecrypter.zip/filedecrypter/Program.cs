﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

class FileDecryptor
{
    private static readonly byte[] key = Encoding.UTF8.GetBytes("A3Tz2tU5r9xZ5p7L");
    private static readonly byte[] iv = Encoding.UTF8.GetBytes("5H8nL3u1P9kR7e2B");

    public static void DecryptDirectory(string directoryPath)
    {
        if (Directory.Exists(directoryPath))
        {
            var files = Directory.GetFiles(directoryPath);
            foreach (var file in files)
            {
                DecryptFile(file);
            }
            Console.WriteLine("All files in the directory have been decrypted.");
        }
        else
        {
            Console.WriteLine("Directory does not exist.");
        }
    }

    private static void DecryptFile(string filePath)
    {
        byte[] encryptedContent = File.ReadAllBytes(filePath);

        using (Aes aes = Aes.Create())
        {
            aes.Key = key;
            aes.IV = iv;

            using (var decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
            using (var ms = new MemoryStream(encryptedContent))
            using (var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
            {
                using (var decryptedStream = new MemoryStream())
                {
                    cs.CopyTo(decryptedStream);
                    byte[] decryptedContent = decryptedStream.ToArray();
                    File.WriteAllBytes(filePath, decryptedContent);
                }
            }
        }

        Console.WriteLine($"Decrypted: {filePath}");
    }

    static void Main(string[] args)
    {
        Console.WriteLine("Enter the directory path to decrypt files:");
        string directoryPath = Console.ReadLine();
        DecryptDirectory(directoryPath);
    }
}
